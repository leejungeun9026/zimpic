export const dummyResult = {
  totalPrice:3200000,
  furniture: {
    침대: 1,
    소파: 1,
    테이블: 1,
    의자: 4,
    티비: 1,
  },
  truck:{
    ton: 2.5,
    count:1,
  },
  workers:{
    count:4
  }
};